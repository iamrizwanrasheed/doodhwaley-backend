var reporter = require('./lib/reporter');

module.exports = reporter;
module.exports.postcss = true;
