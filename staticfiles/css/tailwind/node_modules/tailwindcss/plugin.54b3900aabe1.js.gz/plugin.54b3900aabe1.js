const createPlugin = require('./lib/util/createPlugin')

module.exports = (createPlugin.__esModule ? createPlugin : { default: createPlugin }).default
