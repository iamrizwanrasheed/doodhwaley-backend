# 1.1.2 - 2020-05-16

* Add TypeScript definitions (thanks to @seaneking)

# 1.1.1 - 2017-01-25

* Change decimal rounding technique

# 1.1 - 2017-01-24

* Add optional precision argument

# 1.0 - 2015-05-18

* Initial release
